"""Run with:  pip install -r requirements-dev.txt && pytest -q"""
import os
import sqlite3
import sys
from pathlib import Path

import folium
import pandas as pd
import pytest
import streamlit as st
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import agrishare_utils as U  # noqa: E402

APP = str(ROOT / "app.py")
PAGES = ["Overview", "Explore farms", "Register a farm", "Farm viability", "Farm monitoring",
         "Investment interest", "Agricultural marketplace", "About & privacy", "Admin & exports"]


# ----------------------------------------------------------------- helpers
@pytest.fixture
def dbpath(tmp_path, monkeypatch):
    path = tmp_path / "test.db"
    monkeypatch.setenv("AGRISHARE_DB", str(path))
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    monkeypatch.setenv("SEED_DEMO_DATA", "0")  # tests opt in to demo data explicitly
    st.cache_resource.clear()
    st.cache_data.clear()
    return path


def open_app(page=None):
    at = AppTest.from_file(APP, default_timeout=60).run()
    if page:
        at.sidebar.radio(key="nav").set_value(page).run()
    return at


def click(at, label):
    matches = [b for b in at.button if b.label == label]
    assert matches, f"button {label!r} not found; have {[b.label for b in at.button]}"
    matches[0].click().run()
    return at


def sql(path, query, params=()):
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    rows = con.execute(query, params).fetchall()
    con.commit()
    con.close()
    return rows


def ensure_db(path):
    """Let the app create its own schema first (as it would on a fresh deployment)."""
    if not Path(path).exists():
        AppTest.from_file(APP, default_timeout=60).run()


def add_farm(path, name="Test Farm", farmer="F", crop="Maize", score=50, code_hash=None, verification="Pending"):
    ensure_db(path)
    st.cache_data.clear()
    sql(path, """INSERT INTO farms (name,farmer,country,region,crop,acres,latitude,longitude,land_access,
        water_score,soil_score,market_score,climate_score,operations_score,capital_needed,expected_revenue,
        estimated_cost,description,verification,created_at,currency,update_key_hash)
        VALUES (?,?,'Ghana','R',?,1,6,0.5,'x',?,?,?,?,?,100,200,100,'d',?,'2026-01-01T00:00:00+00:00','EUR',?)""",
        (name, farmer, crop, score, score, score, score, score, verification, code_hash))


def fill_register_form(at, **over):
    v = {"name": "Green Acres", "farmer": "Ama K", "country": "Kenya", "region": "Rift Valley",
         "lat": -0.3, "lon": 36.1}
    v.update(over)
    at.text_input(key="register_name_0").set_value(v["name"])
    at.text_input(key="register_farmer_0").set_value(v["farmer"])
    at.text_input(key="register_country_0").set_value(v["country"])
    at.text_input(key="register_region_0").set_value(v["region"])
    at.number_input(key="register_lat_0").set_value(v["lat"])
    at.number_input(key="register_lon_0").set_value(v["lon"])


# ----------------------------------------------------------------- unit tests
def test_md_escape_blocks_links_images_latex():
    out = U.md_escape("[x](http://evil.com) ![i](http://t/p.png) $$a$$ <b>")
    for ch in "[]()!$<":
        assert ch not in out.replace("\\" + ch, "")


def test_html_escape_safe_for_html_and_js_template_literals():
    out = U.html_escape("<img src=x onerror=alert(1)> `${alert(1)}` \\u0041 \"'")
    for bad in "<>`${}\\\"'":
        assert bad not in out.replace("&#96;", "").replace("&#36;", "")  # entities only


def test_folium_popup_does_not_contain_raw_payload():
    payload = "<script>alert(1)</script>`${alert(2)}`"
    m = folium.Map()
    folium.Marker([1, 1], popup=folium.Popup(f"<b>{U.html_escape(payload)}</b>"),
                  tooltip=U.html_escape(payload)).add_to(m)
    rendered = m.get_root().render()
    assert "<script>alert(1)" not in rendered and "${alert(2)}" not in rendered


def test_url_validation():
    assert U.valid_http_url("https://example.com/a.jpg")
    for bad in ["javascript:alert(1)", "data:text/html,x", "ftp://x.com", "https://", "not a url", "", "http://a b.com"]:
        assert not U.valid_http_url(bad)


def test_email_and_coordinates():
    assert U.valid_email("a@b.co") and not U.valid_email("a@b") and not U.valid_email("a b@c.de")
    assert U.valid_coordinates(6.1, -0.27)
    for lat, lon in [(None, 1), (1, None), (0, 0), (91, 0), (0, 181)]:
        assert not U.valid_coordinates(lat, lon)


def test_csv_formula_injection_neutralised():
    df = pd.DataFrame({"a": ["=HYPERLINK(\"x\")", "+1", "@SUM(A1)", "-2+3", "safe"], "n": [1, -2, 3, 4, 5]})
    out = U.csv_safe(df)
    assert list(out["a"]) == ["'=HYPERLINK(\"x\")", "'+1", "'@SUM(A1)", "'-2+3", "safe"]
    assert list(out["n"]) == [1, -2, 3, 4, 5]  # numbers untouched


def test_update_code_hashing():
    code = U.new_update_code()
    h = U.hash_code(code)
    assert code not in h and U.check_code(code, h) and U.check_code(f"  {code} ", h)
    assert not U.check_code("wrong", h) and not U.check_code(code, None) and not U.check_code("", h)


def test_money_formats_per_currency():
    assert U.money(12000, "EUR") == "€12,000" and U.money(5000, "GHS") == "GHS 5,000"


# ----------------------------------------------------------------- app tests
@pytest.mark.parametrize("seed", ["1", "0"])
def test_every_page_renders_with_and_without_demo_data(dbpath, monkeypatch, seed):
    monkeypatch.setenv("SEED_DEMO_DATA", seed)
    at = open_app()
    for page in PAGES:
        at.sidebar.radio(key="nav").set_value(page).run()
        assert not at.exception, f"{page}: {[x.value for x in at.exception]}"
        assert not [x for x in at.error if "Something went wrong" in x.value], page


def test_admin_disabled_without_password(dbpath):
    at = open_app("Admin & exports")
    assert any("disabled" in e.value for e in at.error)
    assert not at.tabs  # no data exposed


def test_admin_login_flow_and_moderation(dbpath, monkeypatch):
    monkeypatch.setenv("ADMIN_PASSWORD", "s3cret!")
    add_farm(dbpath, name="Shady Farm")
    at = open_app("Admin & exports")
    assert not at.tabs
    at.text_input(key="admin_pw").set_value("wrong")
    click(at, "Sign in")
    assert any("Incorrect" in e.value for e in at.error) and not at.tabs
    at.text_input(key="admin_pw").set_value("s3cret!")
    click(at, "Sign in")
    assert len(at.tabs) == 5
    # reject the farm -> hidden from public pages
    farm_id = sql(dbpath, "SELECT id FROM farms WHERE name='Shady Farm'")[0]["id"]
    at.selectbox(key="admin_farm").set_value(farm_id).run()
    at.selectbox(key=f"admin_status_{farm_id}").set_value("Rejected").run()
    click(at, "Update status")
    assert sql(dbpath, "SELECT verification v FROM farms WHERE id=?", (farm_id,))[0]["v"] == "Rejected"
    public = open_app("Explore farms")
    assert all("Shady Farm" not in x.label for x in public.expander)


def test_register_farm_end_to_end(dbpath):
    at = open_app("Register a farm")
    fill_register_form(at)
    at.checkbox(key="register_consent_0").check()
    click(at, "Submit farm for review")
    assert not at.exception and not at.error
    rows = sql(dbpath, "SELECT * FROM farms WHERE name='Green Acres'")
    assert len(rows) == 1 and rows[0]["verification"] == "Pending" and rows[0]["update_key_hash"]
    # the one-time code is shown and only its hash is stored
    shown = [c.value for c in at.code]
    assert len(shown) == 1 and shown[0] not in str(dict(rows[0])) and U.check_code(shown[0], rows[0]["update_key_hash"])
    # form was blanked for the next entry
    assert at.text_input(key="register_name_1").value == ""


def test_register_validation_keeps_user_input(dbpath):
    at = open_app("Register a farm")
    fill_register_form(at, region="")  # missing region
    at.checkbox(key="register_consent_0").check()
    click(at, "Submit farm for review")
    assert any("complete" in e.value.lower() for e in at.error)
    assert at.text_input(key="register_name_0").value == "Green Acres"
    assert not sql(dbpath, "SELECT 1 FROM farms WHERE name='Green Acres'")


@pytest.mark.parametrize("lat,lon", [(None, 36.1), (0.0, 0.0)])
def test_register_rejects_missing_or_null_island_coordinates(dbpath, lat, lon):
    at = open_app("Register a farm")
    fill_register_form(at)
    at.number_input(key="register_lat_0").set_value(lat)
    at.number_input(key="register_lon_0").set_value(lon)
    at.checkbox(key="register_consent_0").check()
    click(at, "Submit farm for review")
    assert any("latitude" in e.value.lower() for e in at.error)
    assert not sql(dbpath, "SELECT 1 FROM farms WHERE name='Green Acres'")


def test_register_requires_consent_and_blocks_duplicates(dbpath):
    at = open_app("Register a farm")
    fill_register_form(at)
    click(at, "Submit farm for review")
    assert any("confirm" in e.value.lower() for e in at.error)
    add_farm(dbpath, name="Green Acres", farmer="Ama K")
    st.cache_data.clear()
    at = open_app("Register a farm")
    fill_register_form(at)
    at.checkbox(key="register_consent_0").check()
    click(at, "Submit farm for review")
    assert any("already registered" in e.value for e in at.error)
    assert len(sql(dbpath, "SELECT 1 FROM farms WHERE name='Green Acres'")) == 1


def test_farm_picker_handles_duplicate_names(dbpath):
    add_farm(dbpath, name="Same Name", score=10, farmer="one")
    add_farm(dbpath, name="Same Name", score=90, farmer="two")
    at = open_app("Farm viability")
    ids = {r["farmer"]: r["id"] for r in sql(dbpath, "SELECT id, farmer FROM farms WHERE name='Same Name'")}
    assert len(set(at.selectbox(key="viability_farm").options)) == 2  # labels must be distinguishable
    at.selectbox(key="viability_farm").set_value(ids["one"]).run()
    assert at.metric[0].value == "10/100"
    at.selectbox(key="viability_farm").set_value(ids["two"]).run()
    assert at.metric[0].value == "90/100"


def test_monitoring_requires_farm_code(dbpath):
    code = U.new_update_code()
    add_farm(dbpath, name="Coded Farm", code_hash=U.hash_code(code))
    fid = sql(dbpath, "SELECT id FROM farms WHERE name='Coded Farm'")[0]["id"]
    at = open_app("Farm monitoring")
    at.selectbox(key="monitor_farm").set_value(fid).run()
    at.text_area(key="update_note_0").set_value("Planted maize")
    at.text_input(key="update_code_0").set_value("wrong-code")
    click(at, "Add farm update")
    assert any("Invalid farm update code" in e.value for e in at.error)
    assert not sql(dbpath, "SELECT 1 FROM updates")
    at.text_input(key="update_code_0").set_value(code)
    click(at, "Add farm update")
    assert sql(dbpath, "SELECT note FROM updates")[0]["note"] == "Planted maize"


def test_monitoring_rejects_non_http_photo_links(dbpath):
    code = U.new_update_code()
    add_farm(dbpath, name="Coded Farm", code_hash=U.hash_code(code))
    at = open_app("Farm monitoring")
    at.text_area(key="update_note_0").set_value("note")
    at.text_input(key="update_url_0").set_value("javascript:alert(1)")
    at.text_input(key="update_code_0").set_value(code)
    click(at, "Add farm update")
    assert any("http" in e.value for e in at.error) and not sql(dbpath, "SELECT 1 FROM updates")


def test_stored_xss_text_is_escaped_in_rendered_output(dbpath):
    add_farm(dbpath, name="[click me](https://evil.example) ![x](https://t.example/p.png)", farmer="<b>x</b>")
    for page in ("Overview", "Explore farms"):
        at = open_app(page)
        assert not at.exception
        rendered = " ".join(m.value for m in at.markdown) + " ".join(c.value for c in at.caption)
        assert "](https://evil.example)" not in rendered.replace("\\]\\(", "")


def test_investment_interest_validation_and_save(dbpath):
    add_farm(dbpath, name="Pitch Farm")
    at = open_app("Investment interest")
    at.text_input(key="interest_name_0").set_value("Inv Estor")
    at.text_input(key="interest_email_0").set_value("not-an-email")
    click(at, "Register interest")
    assert at.error and not sql(dbpath, "SELECT 1 FROM interests")
    at.text_input(key="interest_email_0").set_value("inv@example.com")
    at.checkbox(key="interest_consent_0").check()
    at.checkbox(key="interest_privacy_0").check()
    click(at, "Register interest")
    rows = sql(dbpath, "SELECT investor_email e FROM interests")
    assert [r["e"] for r in rows] == ["inv@example.com"]


def test_marketplace_create_and_search(dbpath):
    at = open_app("Agricultural marketplace")
    at.text_input(key="listing_title_0").set_value("Maize seed")
    at.text_input(key="listing_loc_0").set_value("Kumasi")
    at.text_input(key="listing_qty_0").set_value("50kg")
    at.text_input(key="listing_price_0").set_value("20 GHS")
    at.text_input(key="listing_contact_0").set_value("+233 000")
    click(at, "Publish listing")
    assert any("confirm" in e.value.lower() for e in at.error)  # consent required
    at.checkbox(key="listing_consent_0").check()
    click(at, "Publish listing")
    assert sql(dbpath, "SELECT title FROM listings")[0]["title"] == "Maize seed"
    at = open_app("Agricultural marketplace")
    at.text_input(key="browse_query").set_value("kumasi").run()
    assert len(at.dataframe[0].value) == 1
    at.text_input(key="browse_query").set_value("nothing-matches").run()
    assert len(at.dataframe[0].value) == 0


def test_legacy_database_is_migrated(dbpath):
    """An existing DB from the original app (no currency / update_key_hash columns) must keep working."""
    con = sqlite3.connect(dbpath)
    con.executescript("""
    CREATE TABLE farms (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, farmer TEXT NOT NULL,
      country TEXT NOT NULL, region TEXT NOT NULL, crop TEXT NOT NULL, acres REAL NOT NULL, latitude REAL NOT NULL,
      longitude REAL NOT NULL, land_access TEXT NOT NULL, water_score INTEGER NOT NULL, soil_score INTEGER NOT NULL,
      market_score INTEGER NOT NULL, climate_score INTEGER NOT NULL, operations_score INTEGER NOT NULL,
      capital_needed REAL NOT NULL, expected_revenue REAL NOT NULL, estimated_cost REAL NOT NULL, description TEXT,
      verification TEXT NOT NULL DEFAULT 'Pending', created_at TEXT NOT NULL);
    INSERT INTO farms (name,farmer,country,region,crop,acres,latitude,longitude,land_access,water_score,soil_score,
      market_score,climate_score,operations_score,capital_needed,expected_revenue,estimated_cost,description,created_at)
      VALUES ('Old Farm','o','Ghana','r','Maize',2,6,0.5,'x',60,60,60,60,60,100,200,100,'d','2025-01-01');""")
    con.commit()
    con.close()
    at = open_app("Overview")
    assert not at.exception
    cols = {r["name"] for r in sql(dbpath, "PRAGMA table_info(farms)")}
    assert {"currency", "update_key_hash"} <= cols
    assert at.metric[0].value == "1"  # Old Farm is visible, nothing was seeded on top of it


def test_mixed_currencies_are_not_summed(dbpath):
    add_farm(dbpath, name="EUR farm")
    sql(dbpath, "UPDATE farms SET currency='GHS', capital_needed=500 WHERE name='EUR farm'")
    add_farm(dbpath, name="Other")
    at = open_app("Overview")
    capital = [m for m in at.metric if m.label == "Investment sought"][0].value
    assert "GHS 500" in capital and "€" in capital and "+" in capital
